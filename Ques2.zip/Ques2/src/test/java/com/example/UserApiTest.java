package com.example;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static org.hamcrest.Matchers.equalTo;

public class UserApiTest {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "https://bfhldevapigw.healthrx.co.in/automation-campus";
    }

    @Test
    public void testCreateUserSuccess() {
        RestAssured.given()
            .header("roll-number", "1")
            .contentType(ContentType.JSON)
            .body("{\"firstName\":\"Test\",\"lastName\":\"Test\",\"phoneNumber\":9999999999,\"emailId\":\"test.test@test.com\"}")
            .when()
            .post("/create/user")
            .then()
            .statusCode(200) // Assuming 200 is the success status code
            .body("message", equalTo("User created successfully")); // Adjust based on API response
    }

    @Test
    public void testCreateUserMissingRollNumber() {
        RestAssured.given()
            .contentType(ContentType.JSON)
            .body("{\"firstName\":\"Test\",\"lastName\":\"Test\",\"phoneNumber\":9999999999,\"emailId\":\"test.test@test.com\"}")
            .when()
            .post("/create/user")
            .then()
            .statusCode(400) // Assuming 400 is the status code for bad request
            .body("error", equalTo("roll-number header is required")); // Adjust based on API response
    }

    @Test
    public void testCreateUserMissingField() {
        RestAssured.given()
            .header("roll-number", "1")
            .contentType(ContentType.JSON)
            .body("{\"firstName\":\"Test\",\"lastName\":\"Test\",\"phoneNumber\":9999999999}")
            .when()
            .post("/create/user")
            .then()
            .statusCode(400) // Assuming 400 is the status code for bad request
            .body("error", equalTo("emailId is required")); // Adjust based on API response
    }

    @Test
    public void testCreateUserDuplicatePhoneNumber() {
        // Create first user
        RestAssured.given()
            .header("roll-number", "1")
            .contentType(ContentType.JSON)
            .body("{\"firstName\":\"Test\",\"lastName\":\"Test\",\"phoneNumber\":9999999999,\"emailId\":\"test1@test.com\"}")
            .when()
            .post("/create/user")
            .then()
            .statusCode(200);

        // Attempt to create second user with the same phone number
        RestAssured.given()
            .header("roll-number", "2")
            .contentType(ContentType.JSON)
            .body("{\"firstName\":\"Test\",\"lastName\":\"Test\",\"phoneNumber\":9999999999,\"emailId\":\"test2@test.com\"}")
            .when()
            .post("/create/user")
            .then()
            .statusCode(400) // Assuming 400 is the status code for bad request
            .body("error", equalTo("phoneNumber must be unique")); // Adjust based on API response
    }

    @Test
    public void testCreateUserDuplicateEmailId() {
        // Create first user
        RestAssured.given()
            .header("roll-number", "1")
            .contentType(ContentType.JSON)
            .body("{\"firstName\":\"Test\",\"lastName\":\"Test\",\"phoneNumber\":9999999990,\"emailId\":\"test@test.com\"}")
            .when()
            .post("/create/user")
            .then()
            .statusCode(200);

        // Attempt to create second user with the same email
        RestAssured.given()
            .header("roll-number", "2")
            .contentType(ContentType.JSON)
            .body("{\"firstName\":\"Test\",\"lastName\":\"Test\",\"phoneNumber\":9999999991,\"emailId\":\"test@test.com\"}")
            .when()
            .post("/create/user")
            .then()
            .statusCode(400) // Assuming 400 is the status code for bad request
            .body("error", equalTo("emailId must be unique")); // Adjust based on API response
    }

    // Add more tests as needed to cover different scenarios
}
